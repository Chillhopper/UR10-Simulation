import rclpy
import subprocess
import time
from rclpy.action import ActionClient
from rclpy.node import Node
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration
from concurrent.futures import Future
from gazebo_msgs.srv import SpawnEntity, GetEntityState, SetEntityState
from geometry_msgs.msg import Pose, Point, Quaternion
from gazebo_msgs.srv import SetPhysicsProperties
from gazebo_msgs.srv import DeleteEntity
from std_msgs.msg import Int32
from nav_msgs.msg import Odometry

class TrajectoryActionClient(Node):
    def __init__(self):
        super().__init__('trajectory_action_client')
        self._action_client = ActionClient(self, FollowJointTrajectory, '/joint_trajectory_controller/follow_joint_trajectory')
        self.get_state_client = self.create_client(GetEntityState, '/demo/get_entity_state')
        self.set_state_client = self.create_client(SetEntityState, '/demo/set_entity_state')
        self.spawn_client = self.create_client(SpawnEntity, '/spawn_entity')
        self.delete_client = self.create_client(DeleteEntity, '/delete_entity')  
        self.follow_wrist_3 = False  # Control variable      
#        self._action_client = ActionClient(self, FollowJointTrajectory, '/scaled_joint_trajectory_controller/follow_joint_trajectory')

    def delete_entity(self, name):
        # Ensure the delete service client is ready
        if not self.delete_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('DeleteEntity service not available')
            return
        
        request = DeleteEntity.Request()
        request.name = name
        future = self.delete_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            self.get_logger().info(f'Successfully deleted {name}')
        else:
            self.get_logger().error(f'Failed to delete {name}.')


    def spawn_box(self, name, position, size=[0.1, 0.1, 0.05]):
        # Ensure the spawn service client is ready
        if not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('SpawnEntity service not available')
            return
        
        # Prepare the request
        request = SpawnEntity.Request()
        request.name = name
        request.xml = f"""
        <sdf version='1.6'>
            <model name='{name}'>
                <static>false</static>
                <pose>{position.x} {position.y} {position.z} 0 0 0</pose>
                <link name='link'>
                    <gravity>false</gravity>
                    <collision name='collision'>
                        <geometry>
                            <box>
                                <size>{size[0]} {size[1]} {size[2]}</size>
                            </box>
                        </geometry>
                    </collision>
                    <visual name='visual'>
                        <geometry>
                            <box>
                                <size>{size[0]} {size[1]} {size[2]}</size>
                            </box>
                        </geometry>
                    </visual>
                </link>
            </model>
        </sdf>
        """
        self.spawn_client.call_async(request)



    def spawn_box_with_gravity(self, name, position, size=[0.2, 0.2, 0.05]):
        # Ensure the spawn service client is ready
        if not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('SpawnEntity service not available')
            return

        # Prepare the request
        request = SpawnEntity.Request()
        request.name = name
        request.xml = f"""
        <sdf version='1.6'>
            <model name='{name}'>
                <static>false</static>
                <pose>{position.x} {position.y} {position.z} 0 0 0</pose>
                <link name='link'>
                    <collision name='collision'>
                        <geometry>
                            <box>
                                <size>{size[0]} {size[1]} {size[2]}</size>
                            </box>
                        </geometry>
                    </collision>
                    <visual name='visual'>
                        <geometry>
                            <box>
                                <size>{size[0]} {size[1]} {size[2]}</size>
                            </box>
                        </geometry>
                         <material>
                            <ambient>0.396078 0.262745 0.129412 1</ambient> <!-- Brown color -->
                            <diffuse>0.396078 0.262745 0.129412 1</diffuse> <!-- Brown color -->
                            <specular>0.01 0.01 0.01 1</specular>
                        </material>
                    </visual>
                </link>
            </model>
        </sdf>
        """
        self.spawn_client.call_async(request)


    def odom_callback(self, msg):
            # Extract the pose from the Odometry message and store it
            self.latest_odom_pose = msg.pose.pose

    def get_entity_state(self, entity_name):
        # Ensure the service client is ready
        if not self.get_state_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('GetEntityState service not available')
            return None
    
        # Create and send the request
        request = GetEntityState.Request()
        request.name = entity_name
        future = self.get_state_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
    
        if future.result() is not None:
            state = future.result().state
            self.get_logger().info(f'{entity_name} Position: {state.pose.position}')
            self.get_logger().info(f'{entity_name} Orientation: {state.pose.orientation}')
            return state.pose
        else:
            self.get_logger().error(f'Failed to get state for entity {entity_name}.')
            return None
            
    def set_entity_state(self, name, pose):
        if not self.set_state_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('SetEntityState service not available')
            return
    
        pose.position.z-=0.03
        request = SetEntityState.Request()
        request.state.name = name
        request.state.pose = pose  # Assuming you're only updating the position
        # Set orientation if necessary, or just copy it from the source
        # request.state.pose.orientation = ...
    
        self.set_state_client.call_async(request)

    def send_trajectory(self, trajectory_points):
        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory.joint_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
        
        goal_msg.trajectory.points = trajectory_points
        
        self._action_client.wait_for_server()
        self._send_goal_future = self._action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

        # Return the future representing the send goal operation
        return self._send_goal_future

    def create_trajectory_point(self, positions, seconds):
        point = JointTrajectoryPoint()
        point.positions = positions
        point.time_from_start = Duration(sec=seconds)
        return point

    def pick_and_place(self):
        # Define "pick" trajectory
        
        self.follow_wrist_3 = False
        
        pick_trajectory = [
            self.create_trajectory_point([3.150, -1.000, 1.569, -2.345, -1.558, -0.895], 3)
            # Add more points here if needed
        ]
        
        
        # Execute "pick" trajectory and wait for it to complete
        self.wait_for_goal_completion(self.send_trajectory(pick_trajectory))
        
        # Optionally, control the gripper to grasp the object here
        

        self.follow_wrist_3 = True  
        
        pick_exit_trajectory = [
            self.create_trajectory_point([3.150, -1.293, 1.569, -2.345, -1.558, -0.895], 3)
            # Add more points here if needed
        ]
        
        # Execute "pick" trajectory and wait for it to complete
        self.wait_for_goal_completion(self.send_trajectory(pick_exit_trajectory))
        
        # Define "place" trajectory
        place_enter_trajectory = [
            self.create_trajectory_point([0.000, -1.690, 1.374, -1.956, -1.558, -0.895], 2)
            # Add more points here if needed
        ]
        
        # Execute "place" trajectory and wait for it to complete
        self.wait_for_goal_completion(self.send_trajectory(place_enter_trajectory))
        
        

        # Define "place" trajectory
        place_trajectory = [
            self.create_trajectory_point([0.000, -1.000, 1.374, -1.956, -1.558, -0.895], 2)
            # Add more points here if needed
        ]
        
        # Execute "place" trajectory and wait for it to complete
        self.wait_for_goal_completion(self.send_trajectory(place_trajectory))

        self.delete_entity('my_box')
        
        # Optionally, control the gripper to release the object here

    def wait_for_goal_completion(self, send_goal_future):

        # Wait for the future from send_trajectory to be completed
        rclpy.spin_until_future_complete(self, send_goal_future)
        
        # After the future is completed, extract the goal handle and wait for the result
        goal_handle = send_goal_future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return
        self.get_logger().info('Goal accepted :)')

        get_result_future = goal_handle.get_result_async()
        #rclpy.spin_until_future_complete(self, get_result_future)
        
        while not get_result_future.done():
            self.get_logger().info('Hello')
            wrist_3_state = self.get_entity_state('wrist_3_link') 
            # Sleep for a bit to prevent spamming the log and to yield execution
            if self.follow_wrist_3:
                self.set_entity_state('my_box', wrist_3_state)
            #time.sleep(0.1)
            # Process any incoming callbacks
            rclpy.spin_once(self, timeout_sec=0.00)

        # Log the result (or handle it accordingly)
        result = get_result_future.result().result
        self.get_logger().info(f'Result: {result}')

    def goal_response_callback(self, future):
        # This is just a placeholder to comply with the API
        pass

    def feedback_callback(self, feedback_msg):
        # Optionally process feedback
        pass


class SignalSubscriber(Node):
    def __init__(self, action_client):
        super().__init__('signal_subscriber')
        self.action_client = action_client
        self.latest_odom_pose = Pose()  # Initialize with an empty Pose
        self.follow_odom = True  # Control whether to follow odometry data

        self.odom_subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10)
        self.subscription = self.create_subscription(
            Int32,
            '/signal',
            self.signal_callback,
            10)
        self.subscription  # prevent unused variable warning

    def odom_callback(self, msg):
        # Directly store the pose from the odometry message
        self.latest_odom_pose = msg.pose.pose
        if self.follow_odom:
            self.latest_odom_pose.position.z+=0.4
            self.action_client.set_entity_state("first_box", self.latest_odom_pose)

    def signal_callback(self, msg):
        self.get_logger().info(f'Received signal: {msg.data}')
        if msg.data == 42:  # Adjust the condition according to your requirement
            self.follow_odom = False
            point = Point(x=0.692598, y=-0.926327, z=0.311125)
            pose = Pose()
            pose.position = point
            pose.position.z += 0.03  # Now this is valid
            self.action_client.set_entity_state("first_box", pose)
            self.action_client.pick_and_place()
            self.action_client.pick_and_place()


def main(args=None):
    rclpy.init(args=args)
    first_box_position = Point(x=-8.0, y=-7.0, z=0.311125)
    initial_box_position = Point(x=-0.655788, y=0.065141, z=0.281500)  # Adjust as needed
    action_client = TrajectoryActionClient()
    action_client.spawn_box_with_gravity(name="first_box", position=first_box_position)

    start_trajectory = [
        action_client.create_trajectory_point([3.150, -1.293, 1.569, -2.345, -1.558, -0.895], 1)
        # Add more points here if needed
    ]
    action_client.wait_for_goal_completion(action_client.send_trajectory(start_trajectory))

    #action_client.spawn_box_with_gravity(name="first_box", position=first_box_position)
    action_client.spawn_box(name="my_box", position=initial_box_position)
    signal_subscriber = SignalSubscriber(action_client)
    rclpy.spin(signal_subscriber)
    signal_subscriber.destroy_node()
    #action_client.pick_and_place()
    rclpy.spin(action_client)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
