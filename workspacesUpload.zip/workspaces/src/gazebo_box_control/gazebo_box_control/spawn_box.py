import rclpy
from rclpy.node import Node
from gazebo_msgs.srv import SpawnEntity

class BoxSpawner(Node):
    def __init__(self):
        super().__init__('box_spawner')
        # Service client for spawning entities in Gazebo
        self.spawn_client = self.create_client(SpawnEntity, 'spawn_entity')

        # Wait for the spawn entity service to be available
        self.get_logger().info('Waiting for spawn entity service...')
        self.spawn_client.wait_for_service()

        self.get_logger().info('Spawn entity service is ready.')
        
        # Spawn the box immediately after service is available
        self.spawn_box()

    def spawn_box(self):
        # SDF definition for the brown box with collision properties
        box_sdf = """
        <sdf version='1.6'>
            <model name='brown_box'>
                <static>false</static>
                <pose>-0.655788 0.065141 0.581500 0 0 0</pose>
                <link name='link'>
                    <collision name='collision'>
                        <geometry>
                            <box>
                                <size>0.2 0.2 0.2</size>
                            </box>
                        </geometry>
                    </collision>
                    <visual name='visual'>
                        <geometry>
                            <box>
                                <size>0.2 0.2 0.2</size>
                            </box>
                        </geometry>
                        <material>
                            <ambient>0.396078 0.262745 0.129412 1</ambient> <!-- Brown color -->
                            <diffuse>0.396078 0.262745 0.129412 1</diffuse> <!-- Brown color -->
                            <specular>0.01 0.01 0.01 1</specular>
                        </material>
                    </visual>
                </link>
            </model>
        </sdf>
        """
        # Create a request with the SDF data
        request = SpawnEntity.Request()
        request.name = 'brown_box'
        request.xml = box_sdf

        # Call the spawn entity service
        future = self.spawn_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)  # Wait for the response

        # Check for response
        if future.result() is not None:
            self.get_logger().info('Box spawned successfully.')
        else:
            self.get_logger().error('Failed to spawn box.')

def main(args=None):
    rclpy.init(args=args)
    box_spawner = BoxSpawner()
    rclpy.spin(box_spawner)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

